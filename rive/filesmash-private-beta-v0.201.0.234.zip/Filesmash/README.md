# FileSmash

FileSmash is a native Win32 file explorer for Windows focused on fast folder open, smooth scrolling, lightweight rendering, and practical Explorer replacement for daily folder browsing.

This repository currently targets a **beta v0.201** desktop build.

## What's New In Beta v0.201

- Private beta unsigned package trust for launcher and admin-helper flows.
- Clearer diagnostics when the launcher/helper package cannot be verified.
- Stable lowercase app binary name: `filesmash.exe`.
- Safer admin rename validation for reserved DOS device names.
- Safer copy/move handling around junctions and reparse points.
- Faster visible-list snapshot publishing during large folder loads.
- Fluent context menu performance optimizations without visual changes.

## Beta Scope

Included in the beta:

- `filesmash.exe`
- `filesmash_launcher.exe`
- stable folder opener and `Win+E` integration
- Today grouped view in custom Details and Grid
- preview pane
- Recycle Bin support
- ZIP compress and extract
- Open With

Not exposed as beta product features:

- full Explorer replacement
- Open/Save dialog replacement
- experimental shell hooks

## Tech

- C++20
- raw Win32
- common controls
- custom Details and Grid surfaces
- async enumeration, icon loading, thumbnails, and preview decoding
- Windows Shell integration for Recycle Bin, properties, rename, and file operations

No Electron, no WebView, and no heavyweight UI framework.

## Build

Open a Visual Studio Developer PowerShell with the Desktop C++ workload installed, then run:

```powershell
cmake -S . -B build\cmake-ninja -G Ninja
cmake --build build\cmake-ninja --config Release
```

Run FileSmash:

```powershell
.\build\cmake-ninja\filesmash.exe
.\build\cmake-ninja\filesmash.exe "C:\Temp"
```

Each build generates a build-local stamp such as `0.201.0.123`. The same stamp
is used for the footer version, Windows file Properties on the EXEs, and
`filesmash_package.json` `buildId`, so active-build checks should use that value
instead of shortcut target paths.

Run the smoke tests:

```powershell
.\build\cmake-ninja\filesmash_smoke_tests.exe
```

For rendering or invalidation-sensitive changes, also run the warning-only
policy checker:

```powershell
git diff --check
python tools\check_invalidation_policy.py
cmake --build build\cmake-ninja --config Release --target filesmash
cmake --build build\cmake-ninja --config Release --target filesmash_smoke_tests
.\build\cmake-ninja\filesmash_smoke_tests.exe
```

Changes touching layout, message routing, Preview, Details, Grid, Column,
thumbnail/icon delivery, or view switching should include manual artifact
validation notes. See `docs\rendering_artifact_validation_checklist.md`.

## Release Folder

The beta release folder is expected to contain:

- `filesmash.exe`
- `filesmash_launcher.exe`
- `filesmash_admin_helper.exe`
- `filesmash_package.json`
- `SetFileSmashAsFolderOpener_STABLE.reg`
- `RestoreExplorerDefault.reg`
- `README.txt`
- `KNOWN_ISSUES.txt`

## Install For Beta Users

Recommended install locations:

- `C:\Program Files\FileSmash`
- `%LOCALAPPDATA%\Programs\FileSmash`

Do not run the private beta package from:

- `Downloads`
- `Temp`
- browser cache folders
- random user-writable staging folders

Install steps:

1. Close FileSmash if it is running.
2. Extract or copy the whole release folder into `C:\Program Files\FileSmash` or `%LOCALAPPDATA%\Programs\FileSmash`.
3. Confirm the folder contains `filesmash.exe`, `filesmash_launcher.exe`, `filesmash_admin_helper.exe`, and `filesmash_package.json`.
4. Run `filesmash.exe`.
5. Open View Options and enable `Use FileSmash to open folders and Win+E` if you want folder-opening integration.

Update steps for a newer beta:

1. Close FileSmash.
2. Replace the entire FileSmash install folder with the new release folder contents.
3. Keep the three EXEs and `filesmash_package.json` from the same release package.
4. Run `filesmash.exe`.
5. You do not need to patch registry again if the install path did not change and integration is still enabled. If the install path changed, launch FileSmash once from the new folder and re-enable the folder/Win+E integration if the View Options menu does not already show it as enabled.

FileSmash repairs stale FileSmash-owned Start Menu and taskbar shortcut metadata
when launched from a trusted install folder. If Windows still opens an old build
path after that launch, unpin FileSmash, run `filesmash.exe` from the install
folder, then pin the running app again.

## Explorer Integration

The stable integration path is:

1. Run FileSmash.
2. Enable `Use FileSmash to open folders and Win+E`.
3. Use `RestoreExplorerDefault.reg` to return to normal Explorer behavior if needed.

The integration toggle only enables from trusted install locations: `Program Files`, `Program Files (x86)`, or `%LOCALAPPDATA%\Programs\FileSmash`.
Installs launched from user download/staging folders such as `Downloads` are intentionally refused by the integration toggle; move or install FileSmash into one of the trusted locations first.
If FileSmash cannot launch, apply the shipped `RestoreExplorerDefault.reg` file from the release folder to remove the per-user Explorer integration keys.

## Administrator Permission Flow

FileSmash does not run the main file manager as administrator. Protected file operations are delegated to the short-lived `filesmash_admin_helper.exe`, which is verified before launch and exits when the operation finishes.

Private beta unsigned packages must keep `filesmash.exe`, `filesmash_launcher.exe`, `filesmash_admin_helper.exe`, and `filesmash_package.json` together in the same stable install folder.

- With UAC fully disabled on an administrator account, Windows may run the helper without showing a prompt. That reflects the user's system security choice.
- Standard users are prompted for administrator credentials. If elevation is canceled or blocked by policy, FileSmash reports that administrator permission was not granted.
- Elevated operations are serialized in v1.0: a second protected operation waits until the first helper exits.
- Junctions and linked locations are refused for elevated operations to avoid operating through a reparse point.
- Network-share elevation behavior is not handled in this beta; protected-folder detection is scoped to local Windows install locations.

## Known Limitations

- Some apps still use Explorer for `Show in folder`.
- Full Explorer replacement is intentionally not enabled in this beta.
- Open and Save dialogs are not replaced.
- Builds are currently unsigned, so SmartScreen warnings are expected on fresh machines.

## Bug Reports

Please include:

- what you clicked
- what you expected
- what happened instead
- screenshot or short screen recording if possible
- exact folder path or filename pattern if the bug is path-specific

Crash reports use `MiniDumpWithDataSegs` to keep files smaller and avoid broad heap capture. They are less detailed for debugging heap corruption, but reduce how much session data can leak; dump files may still contain folder paths from the session.
