FileSmash Beta

Latest package
- Build ID: 0.201.0.234
- Package ID: filesmash-2885d27bcdd238f776bb
- See CHANGELOG.txt for the latest fixes and performance changes.

What's new
- F2 inline rename is hardened across Details, Grid, and Column views.
- Already-running FileSmash instances receive supported Explorer folder/file launches without spawning a second app.
- Column View preview, context menu submenus, sidebar scrolling, search highlights, executable safety preview, and large-folder Grid thumbnail performance have recent fixes.
- Optional F2 diagnostics: launch with FILESMASH_F2_LOG=1 to write %TEMP%\filesmash_f2.log.

Install
- Close FileSmash before replacing files.
- Copy or extract the whole release folder to one stable install folder.
- Recommended folders:
  - C:\Program Files\FileSmash
  - %LOCALAPPDATA%\Programs\FileSmash
- Do not run this private beta from Downloads, Temp, browser cache, or another temporary staging folder.
- Keep `filesmash.exe`, `filesmash_launcher.exe`, `filesmash_admin_helper.exe`, and `filesmash_package.json` together from the same release package.
- Keep `CHANGELOG.txt`, `README.txt`, and `KNOWN_ISSUES.txt` with the release folder for reference.

How to run
- Run `filesmash.exe` to open FileSmash.
- You can also pass a startup folder, for example: `filesmash.exe "C:\Temp"`.
- The build stamp shown in Windows file Properties, the app footer, and `filesmash_package.json` should match.
- If F2 rename still fails in a live build, close FileSmash, set `FILESMASH_F2_LOG=1`, relaunch from this folder, reproduce once, then check `%TEMP%\filesmash_f2.log`.

Update
- Close FileSmash.
- Replace the entire FileSmash install folder with the new release folder contents.
- Always copy the newest `filesmash_package.json` together with the three EXEs.
- You do not need to patch registry again if the install path did not change and integration is still enabled.
- If the install path changed, launch FileSmash once from the new folder and re-enable the folder/Win+E integration if View Options does not already show it as enabled.
- FileSmash repairs stale FileSmash-owned Start Menu and taskbar shortcut metadata when launched from a trusted install folder. If the taskbar still opens an old build path after that launch, unpin FileSmash, run `filesmash.exe` from the install folder, then pin it again.

Folder and Win+E integration
- In FileSmash, open View Options and enable `Use FileSmash to open folders and Win+E`.
- This beta only supports the stable folder opener / Win+E integration.

Restore Windows Explorer
- Run `RestoreExplorerDefault.reg`.
- You can also disable the integration from inside FileSmash.

Known limitation
- Some apps may still use Windows Explorer for `Show in folder`.

Bug reports
- Include what you clicked, what you expected, what happened instead, and if possible a screenshot or short screen recording.
- If the issue is path-specific, include the exact folder or filename pattern involved.
